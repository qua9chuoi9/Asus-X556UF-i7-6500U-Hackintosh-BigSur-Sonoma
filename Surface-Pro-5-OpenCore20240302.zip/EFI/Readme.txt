This release brings crucial fixes, squashed bugs, and magical improvements:

Updated to OpenCore 0.9.8
Robust, and improved USB maps using Apple's native AppleUSBHostMergeProperties API
Map uses MacBookPro14,1 SMBIOS. To change to your own desired model, change the model entry in the kext's info.plist

Enable DisableRtcChecksum for correct timing
Disable LauncherOption correctly